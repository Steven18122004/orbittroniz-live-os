# Orbittroniz starter — setup checklist

## Included
- 20 working browser-based utilities
- Responsive app-like layout, light gradients, subtle 3D hover and motion
- Search/filter, FAQ, About and Contact sections
- SEO title/description/canonical/Open Graph metadata
- `robots.txt`, `sitemap.xml`, favicon, 404 page
- Privacy and Terms draft pages
- Real email/password sign-up, sign-in and password reset integration hooks for Supabase

## 1. Preview locally
Open `index.html` in a modern browser. The QR generator needs an internet connection to load its library.

## 2. Configure real sign-up
1. Create a project at https://supabase.com/
2. In Supabase, open Project Settings / API (or Connect) and copy the Project URL and public anon/publishable key.
3. In `index.html`, find `SUPABASE_URL` and `SUPABASE_ANON_KEY`. Replace the placeholder values.
4. In Supabase Authentication settings, enable email sign-up and configure the Site URL plus allowed redirect URLs for your deployed website.
5. Test signup, email confirmation, sign-in and password reset. Configure production email/SMTP if needed.
6. Never use a `service_role` key or any secret key in browser code. The public key is intended for frontend use when your database policies are correctly configured.
7. The current starter uses authentication only; saved favourites/profile features need additional database tables and access policies.

## 3. Hosting
Use the GitHub repository for version control. For a public/commercial tools business, check the hosting provider's current terms before choosing free hosting; GitHub Pages states it is not intended for free hosting of online businesses or SaaS. Consider Cloudflare Pages or Netlify for the static frontend, and use a server-side function for secret API keys.

## 4. SEO checklist
- Change canonical and sitemap URLs if you use a different domain.
- Add the site in Google Search Console and verify domain ownership.
- Submit `https://YOUR-DOMAIN/sitemap.xml`.
- Create a dedicated crawlable page for each important tool as the project grows; give each page a unique title, description, useful instructions, examples and FAQs.
- Publish original, genuinely useful content; don't generate dozens of thin pages just to target keywords. SEO cannot guarantee ranking.
- Test mobile usability, page speed, keyboard access and tool outputs.
- Add real contact information and update Privacy/Terms to reflect actual analytics, ads, authentication and APIs before launch.

## 5. Important limits
- This is a utilities hub, not yet an AI chat or AI writer. Real AI features require a secure server-side endpoint and an AI provider. Never place secret AI API keys in public JavaScript.
- Supabase account sign-up requires the project configuration above; it will not work until configured.
- Do not add ad scripts until the privacy/consent setup and ad network requirements are reviewed.
